def mul(x,y):
    return x*y

def div(x,y):
    return x/y