name = "Kshitij K Sawant"   # String Variable
age = 20                    # Int Variable
Height = 5.9                # Float Variable 
Valid_to_Vote = True        # Boolean Variable

a = int(input("Enter the Value of A : "))
b = int(input("Enter The Value of B : "))

print(f"Name       : {name}")
print(f"Age        : {age}")
print(f"Height     : {Height}")
print(f"Value of A : {a}")
print(f"Value of B : {b}")

if(Valid_to_Vote):
    print("Valid to Vote")
else:
    print("Invalid to Vote")