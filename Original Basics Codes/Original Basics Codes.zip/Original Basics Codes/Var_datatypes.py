name = "Howard Stark"
age = 20
Height = 5.9
valid_to_Vote = True

print(f"Name   : {name}")
print(f"Age    : {age}")
print(f"Height : {Height}")

if(valid_to_Vote):
    {print("{name} is Eligible to Vote")}
else:
    {print("{name} is not Eligible to Vote")}
